package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;




import com.cg.entites.Student;
@Repository
public class StudentRepositoryImpl implements StudentRepository{

	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public Student save(Student  student) {
		// TODO Auto-generated method stub
		entityManager.persist(student);
		entityManager.flush();

		return student;
	}

	@Override
	public List<Student> loadAll() {
		TypedQuery<Student> query = entityManager.createQuery("SELECT stu FROM Student stu", Student.class);
		return query.getResultList();
	}

	

	
	@Override
	public Student removeEmployee(Student stu, long studId) {
		// TODO Auto-generated method stub
		Student stu1 = entityManager.find(Student.class, studId);
		entityManager.remove(stu1);
		return stu1;
	}


	@Override
	public Student getstudent(long studId) {
		// TODO Auto-generated method stub
		Student student=entityManager.find(Student.class, studId);
		return student;
	}

	@Override
	public Student updateStudent(Student student) {
		// TODO Auto-generated method stub
		Student student1 = entityManager.find(Student.class, student.getStudId());
		System.out.println(student1);
		String name = student.getName();
		student1.setName(name);
		String gender = student.getGender();
		student1.setGender(gender);
		String optionalSubs = student.getOptionalSubs();
		student1.setOptionalSubs(optionalSubs);
		String department = student.getDepartment();
		student1.setDepartment(department);
		System.out.println("vachindi");
		return student1;
		
	}}
