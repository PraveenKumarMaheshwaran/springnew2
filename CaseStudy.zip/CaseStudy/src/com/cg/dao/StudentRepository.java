package com.cg.dao;

import java.util.List;


import com.cg.entites.Student;



public interface StudentRepository {
	
	public abstract Student save(Student student);

	public abstract List<Student> loadAll();
	
	public Student removeEmployee(Student stu ,long studId);
	
	public Student updateStudent(Student student);

	public Student getstudent(long studId);

	

	

}
