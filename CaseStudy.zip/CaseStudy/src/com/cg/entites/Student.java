package com.cg.entites;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="student")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="studId")
	private long studId;
	
	@Column(name="name")
	@NotEmpty(message="give a name ")
	private String name;
	private String gender;
	private String optionalSubs;
	private String department;
	
	@NotNull(message="pay fees")
	private Double fee;
	
	public String getGender() {
		return gender;
	}
	public String getOptionalSubs() {
		return optionalSubs;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setOptionalSubs(String optionalSubs) {
		this.optionalSubs = optionalSubs;
	}
	public long getStudId() {
		return studId;
	}
	public String getName() {
		return name;
	}
	public String getDepartment() {
		return department;
	}
	public Double getFee() {
		return fee;
	}
	public void setStudId(long studId) {
		this.studId = studId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public void setFee(Double fee) {
		this.fee = fee;
	}

	

}
