package com.cg.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StudentRepository;
import com.cg.entites.Student;
@Service
@Transactional
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentRepository dao;
	@Override
	public Student save(Student employee) {
		// TODO Auto-generated method stub
		return dao.save(employee);
	}

	@Override
	public List<Student> loadAll() {
		// TODO Auto-generated method stub
		return dao.loadAll();
	}




	

	@Override
	public Student removeEmployee(Student stu, int studId) {
		// TODO Auto-generated method stub
		return dao.removeEmployee(stu, studId);
	}

	

	@Override
	public Student getstudent(long studId) {
		// TODO Auto-generated method stub
		return dao.getstudent(studId);
	}

	@Override
	public Student updateStudent(Student student) {
		// TODO Auto-generated method stub
		return dao.updateStudent(student);
	}

}
