package com.cg.services;

import java.util.List;

import com.cg.entites.Student;

public interface StudentService {
	
	public abstract Student save(Student employee);

	public abstract List<Student> loadAll();
	
	public Student removeEmployee(Student stu ,int studId);
	public Student updateStudent(Student student);
	public Student getstudent(long studId);


}
