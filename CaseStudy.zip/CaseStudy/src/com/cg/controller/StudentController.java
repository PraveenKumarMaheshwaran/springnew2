package com.cg.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;




import com.cg.entites.Student;
import com.cg.services.StudentService;

@Controller

public class StudentController {
	@Autowired
	private StudentService service;
	
	
	@RequestMapping("/index")
	public String getHomePage(@ModelAttribute("student")@Valid Student student, BindingResult result, Model model){
		String view = null;
		if(result.hasErrors()){
			view="index";
		}
		List<Student> service1=service.loadAll();
		if(service1!=null){
			
		
		model.addAttribute("stuList",service1);
		model.addAttribute("department",new String[]{"Electrical","Electronics","Computure","Civil"});
		model.addAttribute("gender",new String[]{"female","male"});
		model.addAttribute("optionalSubs",new String[]{"powersystems","machines","control Systems"});
		model.addAttribute("student" , new Student());
		view ="index";
		}else{
			model.addAttribute("message","unable to add");
		}
		return view;
	}
	
	@RequestMapping("/save")
	public String saveStudent(@ModelAttribute("student")Student student, Model model){
		
		student = service.save(student);
		model.addAttribute("message","Student with id "+ student.getStudId()+" added successfully in "+student.getDepartment());
		model.addAttribute("student", student);
		
		return "redirect:/index.html";
		
	}
	
	
	
    @RequestMapping("/root")
	public String DeleteStudent(@ModelAttribute("student")Student student,Model model,@RequestParam("studId")int studId)
	{
		model.addAttribute("studId",studId);
		System.out.println("!!!!!!!!!!!!!!!!!!!");
		
		Student stud = service.removeEmployee(student, studId);
		String viewname = "succeess";
		return viewname;
		
	}
    @RequestMapping("dummy")
    public String Dummy(Model model,@RequestParam("studId")int  studId){
System.out.println("vachesaa");
	Student stu = service.getstudent(studId);
	
	int studId1 = (int) stu.getStudId();
	String name = stu.getName();
	String gender = stu.getGender();
	String optionalSubs = stu.getOptionalSubs();
	String department = stu.getDepartment();
	Student stu1 = new Student();
	model.addAttribute("student",stu1);
	model.addAttribute("studId",studId1);
	model.addAttribute("name",name);
	model.addAttribute("gender",new String[]{"female","male"});
	model.addAttribute("optionalSubs",new String[]{"powersystems","machines","control Systems"});
	model.addAttribute("department",new String[]{"Electrical","Electronics","Computure","Civil"});
    String viewname;
    viewname = "update";
    return viewname;
	}
    @RequestMapping(value="/modified",method=RequestMethod.GET)
	public String modifyDetails(@ModelAttribute(value="student") Student student ,@RequestParam("studId")int  studId,Model model)
	{
    	System.out.println(studId);
			System.out.println("cmmmnnngggg maaaa");
		service.updateStudent(student);
		System.out.println("vachindi akko");
		return "success1";
		
	}
    @RequestMapping("/view")
    public String findbyId(Model model,@RequestParam("studId")int  studId)
    {
    	model.addAttribute("studId",studId);
		Student stu = service.getstudent(studId);
		model.addAttribute("student",stu);
		String view = "success2";
    	return view;
    	
    }
}


